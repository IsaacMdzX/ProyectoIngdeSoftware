
-- Rollback: recreate FK constraints (adjust schema/names if needed)
ALTER TABLE stock.inventario ADD CONSTRAINT fk_inventario_playera FOREIGN KEY (id_producto) REFERENCES productos.playeras(id_playera) DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE stock.inventario ADD CONSTRAINT fk_inventario_tenis FOREIGN KEY (id_producto) REFERENCES productos.tenis(id_teni) DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE stock.inventario ADD CONSTRAINT fk_inventario_gorra FOREIGN KEY (id_producto) REFERENCES productos.gorras(id_gorra) DEFERRABLE INITIALLY DEFERRED;
