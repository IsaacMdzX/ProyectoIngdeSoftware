-- Agrega las columnas image_filename a las tablas de productos
-- Ajusta el schema/nombres si difieren en tu DB
ALTER TABLE productos.tenis ADD COLUMN IF NOT EXISTS image_filename VARCHAR(255);
ALTER TABLE productos.playeras ADD COLUMN IF NOT EXISTS image_filename VARCHAR(255);
ALTER TABLE productos.gorras ADD COLUMN IF NOT EXISTS image_filename VARCHAR(255);
